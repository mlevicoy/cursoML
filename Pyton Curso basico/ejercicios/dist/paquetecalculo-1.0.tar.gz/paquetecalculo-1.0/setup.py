from setuptools import setup

setup(
	name="paquetecalculo",
	version="1.0",
	desription="Paquete de redondeo y potencia",
	author="Manuel",
	author_email="mlevicoy@gmail.com",
	url="www.laputamadre.cl",
	packages=["calculos", "calculos.redondeo_potencia"]
	)